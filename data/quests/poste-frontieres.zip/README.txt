RPG GPS — Export de conception

La quête et ses dialogues sont des définitions pour QuestService. Le scénario, les lieux, les placements et la play area sont séparés. Les lieux sans position imposée utilisent une position neutre dans le catalogue et une stratégie random dans le scénario ; le serveur doit les placer dans le terrain de la partie.

Cet export ne modifie pas le catalogue du jeu ni les parties en cours. Intégrer ces fichiers dans le catalogue serveur, puis tester les parcours en GPS et simulation. Les preuves de combat et positions sont toujours validées en partie.

Remarques de validation :
- Aucune play area liée : les contraintes géographiques seront vérifiées lors du placement en partie.
- Déclencheur lié à une autre quête : Le poste des frontières.